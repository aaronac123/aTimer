//
//  ViewController.swift
//  stopWatch
//
//  Created by Aaron Cunningham on 4/5/17.
//  Copyright © 2017 Aaron Cunningham. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
   
    @IBOutlet var aTimer1: UILabel!
    @IBOutlet var aTimer: UILabel!
    @IBOutlet var milliSeconds: UILabel!
    @IBOutlet var secondS: UILabel!
    @IBOutlet var byMe: UILabel!
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var stopTime: UILabel!

    
    
    let date = Date()
    
    
    
    
    let images: [String] = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19"]
    
    let number = UInt32(images.count)
    
    let randNumber = Int(arc4random_uniform(number))
    
    
    
    
    
   
    
    
   // var currentImage = 0
    
    var startTIme = TimeInterval()
    
    func updateTime()
    {
    
    let currentTIme =
    Date.timeIntervalSinceReferenceDate
        
    var elapsedTime: TimeInterval = currentTIme - startTIme

    let minutes = UInt8(elapsedTime / 60.0)

    elapsedTime -= (TimeInterval(minutes) * 60)

    let seconds = UInt8(elapsedTime)

    elapsedTime -= TimeInterval(seconds)

    let fraction = UInt8(elapsedTime * 100)

    let strMinutes = String(format: "%02d", minutes)

    let strSeconds = String(format: "%02d", seconds)

    let strFraction = String(format: "%02d", fraction)

    milliSeconds?.text = "\(strFraction)"
    secondS?.text = "\(strSeconds)"
    stopTime?.text = "\(strMinutes)"
    }
    
   
    
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    
  
    
    
    
    
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?)
    {
        
    if event?.subtype == UIEventSubtype.motionShake
    {
    
    print("SHAKE")
    
   images[randNumber]
    }
        
   // imageView.image = UIImage(named: images[currentImage])
            
    //if (currentImage == images.count - 1)
    //{
    
   // currentImage = 0
   // }
    
   // else
  //  {
    
  //  currentImage += 1
  //  }
   //  }
    
    }
   
    
    
    
    
    
    
    var time = 0
    //timer
    var timer = Timer()
    //func action()
    //{
    //time += 1
    //stopTime.text = String(time)
    //}
   
    
    
    
    
    @IBAction func startPause(_ sender: UISwitch) {
        
    if ( sender.isOn == true)
    {
    
    
        let aSelector : Selector = #selector(ViewController.updateTime)
            
    timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: aSelector, userInfo: nil, repeats: true)
            
            
    startTIme = Date.timeIntervalSinceReferenceDate
    }

            
    //timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.action), userInfo: nil, repeats: true)}
            
    else
    {
    
    timer.invalidate()
        }
   
    
    
    func reset(_ sender: UIButton)
    {
        
    timer.invalidate()
    time = 0
    stopTime.text = "00"
    secondS.text = "00"
    milliSeconds.text = "00"
    }
    }
    override func didReceiveMemoryWarning()
    {
    super.didReceiveMemoryWarning()
        
    }

    }
